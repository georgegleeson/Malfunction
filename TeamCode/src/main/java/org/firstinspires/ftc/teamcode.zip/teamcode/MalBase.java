package org.firstinspires.ftc.teamcode;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public interface MalBase {
    public void log(Object value, String itemName, MalGlobals.DEBUG_LEVELS level);
}
