package org.firstinspires.ftc.teamcode;

public class MalGlobals {
    public enum DEBUG_LEVELS {
        VERBOSE,
        INFO,
        NONE;
    }

    public static DEBUG_LEVELS DEBUG = DEBUG_LEVELS.VERBOSE;

    public MalGlobals() {

    }

}
